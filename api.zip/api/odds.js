module.exports = async (req,res) => {
 res.setHeader("Cache-Control","s-maxage=180, stale-while-revalidate=300");
 const key=process.env.ODDS_API_KEY;
 if(!key)return res.status(200).json({mode:"sample",message:"Configure ODDS_API_KEY to retrieve provider odds.",odds:[]});
 try{
  const sport=req.query.sport||"soccer_epl";
  const url=`https://api.the-odds-api.com/v4/sports/${encodeURIComponent(sport)}/odds/?regions=uk,eu&markets=h2h&oddsFormat=decimal&apiKey=${encodeURIComponent(key)}`;
  const r=await fetch(url);
  if(!r.ok)throw new Error(`Odds provider returned ${r.status}`);
  const data=await r.json();
  return res.status(200).json({mode:"live",updatedAt:new Date().toISOString(),odds:data.map(e=>({id:e.id,sport:e.sport_title,home:e.home_team,away:e.away_team,commenceTime:e.commence_time,bookmakers:e.bookmakers||[]}))});
 }catch(e){return res.status(502).json({mode:"error",odds:[],message:"Live odds unavailable. Check provider coverage, API key and quota."});}
};