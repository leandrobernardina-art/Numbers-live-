const demo = [
 {id:"demo-1",competition:"Premier League",home:"Arsenal",away:"Chelsea",utcDate:"2026-10-12T18:00:00Z",status:"SCHEDULED",demo:true},
 {id:"demo-2",competition:"La Liga",home:"Real Madrid",away:"Barcelona",utcDate:"2026-10-12T16:15:00Z",status:"SCHEDULED",demo:true},
 {id:"demo-3",competition:"Serie A",home:"Inter",away:"AC Milan",utcDate:"2026-10-12T17:45:00Z",status:"SCHEDULED",demo:true}
];
module.exports = async (req,res) => {
 res.setHeader("Cache-Control","s-maxage=120, stale-while-revalidate=300");
 const key=process.env.FOOTBALL_DATA_API_KEY;
 if(!key){return res.status(200).json({mode:"sample",updatedAt:new Date().toISOString(),matches:demo,message:"Configure FOOTBALL_DATA_API_KEY for provider data."});}
 try{
  const now=new Date(), end=new Date(now.getTime()+48*60*60*1000);
  const url=`https://api.football-data.org/v4/matches?dateFrom=${now.toISOString().slice(0,10)}&dateTo=${end.toISOString().slice(0,10)}`;
  const r=await fetch(url,{headers:{"X-Auth-Token":key}});
  if(!r.ok) throw new Error(`Football data provider returned ${r.status}`);
  const data=await r.json();
  const matches=(data.matches||[]).filter(m=>new Date(m.utcDate)>=now && new Date(m.utcDate)<=end && !["FINISHED","CANCELLED","POSTPONED","SUSPENDED"].includes(m.status)).map(m=>({id:String(m.id),competition:m.competition?.name||"Football",home:m.homeTeam?.name||"Home",away:m.awayTeam?.name||"Away",utcDate:m.utcDate,status:m.status,homeCrest:m.homeTeam?.crest||null,awayCrest:m.awayTeam?.crest||null,demo:false}));
  return res.status(200).json({mode:"live",updatedAt:new Date().toISOString(),matches});
 }catch(e){return res.status(502).json({mode:"error",updatedAt:new Date().toISOString(),matches:[],message:"Live fixture provider unavailable. Check API key, plan and quota."});}
};