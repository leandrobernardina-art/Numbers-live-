module.exports = async (req,res) => {
 const auth=req.headers.authorization;
 if(process.env.CRON_SECRET && auth !== `Bearer ${process.env.CRON_SECRET}`) return res.status(401).json({ok:false});
 // This endpoint is a scheduler hook. Provider endpoints fetch fresh data on demand;
 // add a database/cache write here when persistent scheduled snapshots are configured.
 return res.status(200).json({ok:true,scheduledAt:new Date().toISOString(),message:"Refresh hook ran. Configure a database for persisted snapshots."});
};